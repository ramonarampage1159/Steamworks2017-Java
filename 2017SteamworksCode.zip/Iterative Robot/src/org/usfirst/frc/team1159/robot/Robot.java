package org.usfirst.frc.team1159.robot;

import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Talon;
//import edu.wpi.first.wpilibj.TalonSRX;
import edu.wpi.first.wpilibj.Timer;
//import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
//import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
/*import edu.wpi.first.wpilibj.CANTalon;
import edu.wpi.first.wpilibj.CANTalon.FeedbackDevice;*/
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.DigitalInput;
//import edu.wpi.first.wpilibj.SampleRobot;
//import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import com.ctre.phoenix.motorcontrol.can.*;

public class Robot extends IterativeRobot {
	// Choices
	// Autonomous Choices
	final String driveForwardAuto = "Drive forward";
	final String driveLowBarAuto = "Low Bar";
	String autoSelected;
	// Driver
	Joystick driver;
	RobotDrive myDrive;
	Talon leftWheels, rightWheels;
	// Knight
	Joystick knight;
	// Shooting
	TalonSRX pickUpMotor;
	TalonSRX shootUpMotor;
	int shootHighDelay = 25;
	int shootHighDelayCounter;
	DigitalInput limitSwitchPickUp;
	// Arm
	TalonSRX armMotor;
	DigitalInput limitSwitchArmForward, limitSwitchArmBackward;
	// Camera
	CameraServer server;
	// Other
	int autoLoopCounter;
	// private GenericHID GenericHID;
	SendableChooser chooser;

	public void robotInit() {
		// Choices
		chooser = new SendableChooser();
		// Autonomous Choices
		chooser.addDefault("Drive forward", driveForwardAuto);
		chooser.addObject("Low Bar", driveLowBarAuto);
		SmartDashboard.putData("Auto choices", chooser);
		// Driving
		leftWheels = new Talon(0);
		rightWheels = new Talon(1);
		myDrive = new RobotDrive(leftWheels, rightWheels); // PWM 0 and 1
		myDrive.setSafetyEnabled(false);
		driver = new Joystick(1); // USB 1 on the Driver Station
		// Knight
		knight = new Joystick(2); // USB 2 on the Driver Station
		// Shooting
		pickUpMotor = new TalonSRX(3); // PWM 2
		shootUpMotor = new TalonSRX(2); // PWM 3
		limitSwitchPickUp = new DigitalInput(2); // DIO2
		// Arm
		armMotor = new TalonSRX(4); // PWM 4
		limitSwitchArmForward = new DigitalInput(0); // DIO0
		limitSwitchArmBackward = new DigitalInput(1); // DIO1
		/*
		 * //Camera server = CameraServer.getInstance(); server.setQuality(50);
		 * server.startAutomaticCapture("cam2");
		 */
	}

	/**
	 * This autonomous, along with the chooser code above shows how to select
	 * between different autonomous modes Code works with the Java
	 * SmartDashboard. Add additional modes to the switch structure below with
	 * additional strings. If using the SendableChooser make sure to add them to
	 * the chooser code above as well.
	 */

	public void autonomousInit() {
		autoSelected = (String) chooser.getSelected();
		System.out.println("Auto selected: " + autoSelected);
		myDrive.setSafetyEnabled(false);
	}

	public void autonomousPeriodic() {
		switch (autoSelected) {

		case driveForwardAuto:
		default:
			myDrive.setSafetyEnabled(false);
			myDrive.drive(-0.9, 0.0); // drive forwards (shooter)
			Timer.delay(2); // for 2 seconds
			myDrive.drive(0.0, 0.0); // stop robot
			Timer.delay(16);
			break;

		case driveLowBarAuto:
			myDrive.setSafetyEnabled(false);
			myDrive.drive(0.7, 0.0); // drive forwards (arm)
			Timer.delay(2); // for 2 seconds
			myDrive.drive(0.0, 0.0); // stop robot
			Timer.delay(16);
			break;
		}
	}

	/**
	 * This function is called once each time the robot enters tele-operated
	 * mode
	 */
	public void teleopInit() {
		shootHighDelayCounter = 0;
	}

	/**
	 * This function is called periodically during operator control
	 */
	public void teleopPeriodic() {
		myDrive.setSafetyEnabled(true);
		// Driving
		double forward = driver.getY();
		double turn = driver.getX() + 0.325;
		myDrive.arcadeDrive(forward, turn);
		// Pick up and shoot balls
		Button rOne = new JoystickButton(knight, 6); // Ball pick up
		Button lOne = new JoystickButton(knight, 5); // shoot low
		Button square = new JoystickButton(knight, 3); // shoot high
		if (rOne.get()) {
			if (limitSwitchPickUp.get()) {
				pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput ,0.0);
			} else {
				pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, -0.5); // pick up
			}
		} else if (lOne.get()) {
			pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 1.00); // shoot low
		} else if (square.get()) {
			if (shootHighDelayCounter > shootHighDelay) {
				pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, -1.0); // after delay, drive ball into shoot
										// high wheels
				shootUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.9); // start driving shoot high motors
				shootHighDelayCounter++;

			} else {

				shootHighDelayCounter++; // reset counter if button is released
				pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.0); // stop both motors
				shootUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.9);
			}
		} else {
			shootHighDelayCounter = 0;
			shootUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.0);
			pickUpMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.0);
		}

		// Move arm
		Button triangle = new JoystickButton(knight, 4); // lowers arm
		Button circle = new JoystickButton(knight, 2); // raises arm
		if (triangle.get() && !limitSwitchArmForward.get()) {
			armMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0.7);
		} else if (circle.get() && !limitSwitchArmBackward.get()) {
			armMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, -0.7);
		} else {
			armMotor.set(com.ctre.phoenix.motorcontrol.ControlMode.PercentOutput, 0);
		}
	}

	/**
	 * This function is called periodically during test mode
	 */
	public void testPeriodic() {
		LiveWindow.run();
	}

}
